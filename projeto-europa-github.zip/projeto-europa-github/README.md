# Projeto Europa | Elite Football Tracker

App web em **HTML, CSS e JavaScript puro**, responsivo e preparado como **PWA** para acompanhar a rotina e evolução de um atleta de futebol.

## Recursos
- Dashboard com resumo do dia
- Rotina semanal editável
- Controle diário com energia, cansaço, nota e observações
- Análise de jogos
- Metas mensais
- Evolução física com gráficos em SVG
- Treino de abdômen/core
- Modo motivação + contador para a Alemanha
- Salvamento em `localStorage`
- PWA com `manifest.webmanifest` e `service worker`

## Estrutura
- `index.html`
- `manifest.webmanifest`
- `sw.js`
- `icons/icon-192.png`
- `icons/icon-512.png`
- `social-cover.png`

## Como publicar no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta.
3. Vá em **Settings > Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/root`.
6. Salve.

Depois disso, o app ficará online.

## Observação
Os dados ficam salvos no navegador do dispositivo. Se limpar o navegador, os dados do `localStorage` podem ser perdidos.
